<?php $__env->startSection('title', 'Identitas Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="mb-5">Topik <strong><?php echo e($data->Soal->nama); ?></h5>
                        
                        <div class="col-md-12 mb-5">
                            <span>Hasil Tes</span>
                            <h2 class=""><?php echo e(array_sum($data->nilai)); ?></h2>
                        </div>

                        <div class="col-md-12">
                            <a href="<?php echo e(route('ayo_tes')); ?>" class="form-control btn btn-success">Menu Utama</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/student/nilai.blade.php ENDPATH**/ ?>