<div class="navbar-collapse collapse">
	<ul class="navbar-nav navbar-align">
		<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" title="<?php echo e(strtoupper(auth()->user()->nama)); ?>" data-bs-toggle="dropdown">
				<i class="align-middle me-1" data-feather="user"></i><?php echo e(auth()->user()->nama); ?></a>
			<div class="dropdown-menu dropdown-menu-end">
				<?php if(in_array(auth()->user()->role, ['admin'])): ?>
					<a class="dropdown-item <?php echo e(Route::is('user.index') ? 'active' : ''); ?>" href="<?php echo e(route('user.index')); ?>" >Manajemen Akun</a>
				<?php endif; ?>
				<a class="dropdown-item btn-edit" href="<?php echo e(route('user.edit', auth()->user()->id)); ?>" >Profile</a>

				<a class="dropdown-item" href="#" onclick="event.preventDefault();
				document.getElementById('logout-form').submit();">Logout
					<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
						<?php echo csrf_field(); ?>
					</form>
				</a>
			</div>
		</li>
	</ul>
</div>

<?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/components/navbar.blade.php ENDPATH**/ ?>