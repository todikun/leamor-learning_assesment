<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
      <div class="row justify-content-md-center text-center d-flex">
          <div class="pb-3 mb-3">

            <?php if(auth()->user()->role == 'teacher'): ?>
                <a class="btn btn-success rounded-circle" href="<?php echo e(route('soal.create')); ?>">
                    <i class="align-middle" data-feather="plus"></i> 
                </a>
                <h5 class="mt-2">Create Proyek</h5>
            <?php endif; ?>

            <?php if(auth()->user()->role == 'student'): ?>
                <img src="<?php echo e(asset('dist/img/fighting.png')); ?>" alt="err" height="300px" width="auto" />

                <form action="<?php echo e(route('ujian.akses')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row row justify-content-md-center mt-2">
                        <div class="col-4">
                            <input type="text" name="token" placeholder="Kode Akses" class="form-control mb-2" required />
                            <button type="submit" class="form-control btn btn-success mb-2">Submit</button>
                        </div>
                    </div>
                </form>
            <?php endif; ?>

          </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $('.btn-add').on('click',function(e){
            e.preventDefault();
            var url = $(this).attr('href');
            $.ajax({
                url: url,
                dataType: 'HTML',
                method: 'GET',
                success: function (result) {
                    $('#modal-form').find('.modal-title').html('Create Proyek');
                    $('#modal-form').find('.modal-body').html(result);
                    $('#modal-form').modal('show');
                },
                error: function (err) {
                    console.log(err);
                },
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/index.blade.php ENDPATH**/ ?>