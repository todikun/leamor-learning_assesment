<nav id="sidebar" class="sidebar js-sidebar">
	<div class="sidebar-content js-simplebar">
		<a class="sidebar-brand" href="<?php echo e(url('dashboard')); ?>">
			<span class="align-middle">Leamor</span>
		</a>

		<ul class="sidebar-nav">

			<?php if(in_array(auth()->user()->role, ['teacher', 'admin'])): ?>
				<li class="sidebar-item <?php echo e(Route::is('proyek.index') ? 'active' : ''); ?>">
					<a class="sidebar-link" href="<?php echo e(route('proyek.index')); ?>">
						<i class="align-middle " data-feather="folder"></i> <span class="align-middle">Semua Proyek</span>
					</a>
				</li>

				<li class="sidebar-item <?php echo e(Route::is(['proyek.my', 'soal.*']) ? 'active' : ''); ?>">
					<a class="sidebar-link" href="<?php echo e(route('proyek.my')); ?>">
						<i class="align-middle " data-feather="file-text"></i> <span class="align-middle">Proyek Anda</span>
					</a>
				</li>

				<li class="sidebar-item <?php echo e(Route::is('rapor.teacher.*') ? 'active' : ''); ?>">
					<a class="sidebar-link" href="<?php echo e(route('rapor.teacher.index')); ?>">
						<i class="align-middle " data-feather="layers"></i> <span class="align-middle">Rapor</span>
					</a>
				</li>

				<li class="sidebar-item <?php echo e(Route::is('proyek.deleted') ? 'active' : ''); ?>">
					<a class="sidebar-link" href="<?php echo e(route('proyek.deleted')); ?>">
						<i class="align-middle " data-feather="trash"></i> <span class="align-middle">Sampah</span>
					</a>
				</li>
			<?php endif; ?>

			<?php if(in_array(auth()->user()->role, ['student'])): ?>

				<li class="sidebar-item <?php echo e(Route::is('ayo_tes') ? 'active' : ''); ?>">
					<a class="sidebar-link" href="<?php echo e(route('ayo_tes')); ?>">
						<i class="align-middle " data-feather="file-text"></i> <span class="align-middle">Ayo Tes</span>
					</a>
				</li>

				<li class="sidebar-item <?php echo e(Route::is('rapor.student.*') ? 'active' : ''); ?>">
					<a class="sidebar-link" href="<?php echo e(route('rapor.student.index')); ?>">
						<i class="align-middle " data-feather="layers"></i> <span class="align-middle">Rapor</span>
					</a>
				</li>
			<?php endif; ?>
		</ul>
	</div>
</nav><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/components/sidebar.blade.php ENDPATH**/ ?>