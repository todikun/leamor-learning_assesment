<?php $__env->startSection('title', 'Soal'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3"></h1>
    <div>

        <a href="<?php echo e(route('proyek.my')); ?>" class="btn btn-secondary">
            <i class="align-middle" data-feather="folder"></i> Folder View
        </a>

        <a href="<?php echo e(route('soal.create')); ?>" class="btn btn-primary ">
            <i class="align-middle" data-feather="plus"></i> Create Soal
        </a>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <table id="myTable" class="table">
                    <thead>
                        <tr class="text-center">
                            <th>#</th>
                            <th>Nama</th>
                            <th>Akses Ujian</th>
                            <th>Durasi Ujian</th>
                            <th>Akses Mandiri</th>
                            <th>Kode Akses</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php if($item->waktu_akses_ujian == null): ?>
                                    <span class="badge bg-secondary">setiap saat</span>
                                <?php else: ?>
                                <?php echo e(date('d F Y H:i', strtotime($item->waktu_akses_ujian))); ?>

                                <?php endif; ?>

                                </td>
                                <td><?php echo e($item->waktu_ujian); ?> menit</td>
                                <td>
                                    <h1 class="text-<?php echo e($item->is_mandiri == true ? 'success' : 'danger'); ?>">
                                        <i class="fa fa-<?php echo e($item->is_mandiri == true ? 'check' : 'times'); ?>"></i>
                                    </h1>
                                </td>
                                <td>
                                    <div class="d-flex justify-content-center token-container">
                                        <?php if($item->is_mandiri == true): ?>
                                        <h1 class="text-danger">
                                            <i class="fa fa-times"></i>
                                        </h1>
                                        <?php else: ?>
                                        <h5 class="token-show fw-bold d-none"><?php echo e($item->token); ?></h5>
                                        <h3 class="token-hide fw-bold">*********</h3>
                                        <span style="cursor: pointer;" class="text-dark ms-2 btn-token">
                                            <i class="icon fa fa-eye-slash"></i>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('soal.users', $item->id)); ?>"
                                        class="btn btn-sm btn-success">
                                        <i class="fa fa-users"></i> 
                                    </a>
                                    <a href="<?php echo e(route('soal.preview', $item->id)); ?>"
                                        class="btn btn-sm btn-secondary">
                                        <i class="fa fa-eye"></i> Preview
                                    </a>
                                    <a href="<?php echo e(route('soal.show', $item->id)); ?>"
                                        class="btn btn-sm btn-warning">
                                        <i class="fa fa-edit"></i> Soal
                                    </a>
                                    <form
                                        action="<?php echo e(route('soal.destroy', $item->id)); ?>"
                                        method="post" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit"
                                            class="btn btn-sm btn-danger"
                                            onclick="return confirm('Apakah yakin data ini ingin dihapus?')">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                    <a href="<?php echo e(route('soal.edit', $item->id)); ?>"
                                        class="btn btn-sm btn-secondary">
                                        <i class="fa fa-gear"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%" class="text-center">No data</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<script>
    

    // event button edit
    $('.btn-add').on('click', function (e) {
        e.preventDefault();
        var url = $(this).attr('href');
        var modalSize = $(this).attr('data-modal') ?? '';

        $.ajax({
            url: url,
            dataType: 'HTML',
            method: 'GET',
            success: function (result) {
                $('#modal-form').find('#modal-label').html('Tambah Pasien');
                $('#modal-form').find('.modal-dialog').addClass(modalSize);
                $('#modal-form').find('.modal-body').html(result);
                $('#modal-form').modal('show');
            },
            error: function (err) {
                console.log(err);
            },
        });
    });

    $('.btn-edit').on('click', function (e) {
        e.preventDefault();
        var url = $(this).attr('href');

        $.ajax({
            url: url,
            dataType: 'HTML',
            method: 'GET',
            success: function (result) {
                $('#modal-form').find('#modal-label').html('Edit Gejala');
                $('#modal-form').find('.modal-body').html(result);
                $('#modal-form').modal('show');
            },
            error: function (err) {
                console.log(err);
            },
        });
    });

    $('.btn-token').on('click', function(){
        let icon = $(this).find('.icon');
        let tokenShow = $(this).closest('.token-container').find('.token-show');
        let tokenHide = $(this).closest('.token-container').find('.token-hide');
        if (icon.hasClass('fa-eye-slash')) {
            icon.removeClass('fa-eye-slash');
            icon.addClass('fa-eye');
            tokenShow.removeClass('d-none');
            tokenHide.addClass('d-none');
            return;
        }
        icon.addClass('fa-eye-slash');
        icon.removeClass('fa-eye');
        tokenShow.addClass('d-none');
        tokenHide.removeClass('d-none');
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/teacher/soal/index.blade.php ENDPATH**/ ?>