<?php $__env->startSection('title', 'Nilai Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="mb-5">Topik <strong><?php echo e($data->Soal->nama ?? $data['soal']); ?></h5>
                        
                        <div class="col-md-12 mb-5">
                            <span>Hasil Tes</span>
                            <h2 class=""><?php echo e(array_sum($data->nilai ?? $data['nilai'])); ?></h2>
                        </div>

                        <div class="col-md-12">
                            <div class="d-flex justify-content-center">
                                <?php if(auth()->user()->role == 'teacher'): ?>
                                <div class="col-md-5 ms-3">
                                    <a href="<?php echo e(route('soal.index')); ?>" class="form-control btn btn-success">Menu Utama</a>      
                                </div>
                                <?php else: ?>
                                <div class="col-md-5 ms-3">
                                    <a href="<?php echo e(route('dashboard')); ?>" class="form-control btn btn-success">Menu Utama</a>
                                </div>
                                <div class="col-md-5 ms-3">
                                    <a href="<?php echo e(route('rapor.student.detail', $data->Soal->id)); ?>" class="form-control btn btn-primary">Rapor</a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/ujian/nilai.blade.php ENDPATH**/ ?>