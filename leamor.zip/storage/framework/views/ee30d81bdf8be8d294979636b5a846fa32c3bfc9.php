
<form action="<?php echo e(route('rapor.teacher.koreksi_store', $data->id)); ?>" method="post">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="no_soal" value="<?php echo e(request('index')); ?>" />
    <h5 class="card-title mb-2">Nilai </h5>
    <input type="number" name="nilai" class="form-control mb-2" required />

    <button type="submit" class="form-control btn btn-success mt-2">Simpan</button>
</form>

<script>
    $('.summernote').summernote({
        tabsize: 2,
        height: 120,
        toolbar: [
            ['insert', ['picture']],
        ]
    });
</script>

<?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/teacher/rapor/koreksi.blade.php ENDPATH**/ ?>