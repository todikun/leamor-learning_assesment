<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan Pembinaan Atlit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>
<body>
    <div class="container">
        <div class="row">
            <h3 class="text-center my-2">KOMITE OLAHRAGA NASIONAL INDONESIA</h3>
            <h3 class="text-center my-2">( K O N I )</h3>
            <h3 class="text-center my-2">KOTA SUNGAI PENUH</h3>
            <span style="font-size: 12px" class="text-center">Alamat: Jl. KH. Ahmad Dahlan RT.02 Desa Koto Renah Kecamatan Pesisir Bukit</span> <br>
            <span style="font-size: 12px" class="text-center">Kota Sungai Penuh</span>
            <hr class="my-2">

            <h6 class="text-center my-2">LAPORAN DATA ATLIT</h6>

            <table id="myTable" class="table">
                <thead>
                    <tr class="text-center">
                        <th>No</th>
                        <th>Soal</th>
                        <th>Feedback</th>
                        <th>Jawaban</th>
                        <th>Skor</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data->Soal->SoalDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-center">
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo $item->pertanyaan; ?></td>
                            <td><?php echo e($item->feedback); ?></td>
                            <td><?php echo $item->opsi_jawaban[$data->jawaban[$key] - 1]; ?></td>
                            <td><?php echo e($data->nilai[$key]); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="100%" class="text-center">No data</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            

        </div>
    </div>

    <script>
        window.print();
    </script>
</body>
</html><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/teacher/rapor/file_ujian.blade.php ENDPATH**/ ?>