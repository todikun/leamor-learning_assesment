<?php $__env->startSection('title', 'Identitas Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card rounded">
                    <div class="card-body">
                        
                        <p class="text-center">Topik <strong><?php echo e($soal->nama); ?></p>
                        <form action="<?php echo e(route('ujian.form')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="soal_id" value="<?php echo e($soal->id); ?>" />
                            <div class="row justify-content-center mt-3 mb-1">
                                <?php $__currentLoopData = $soal->pernyataan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="text" name="pernyataan[]" class="form-control mb-3" placeholder="<?php echo e($item); ?>" required />
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button type="submit" class="form-control btn btn-success btn-lg mb-1">Mulai</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/student/identitas.blade.php ENDPATH**/ ?>