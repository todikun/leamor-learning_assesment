
<form action="<?php echo e(route('user.store')); ?>" method="post">
    <?php echo csrf_field(); ?>

    <h5 class="card-title my-3">Nama  <span class="text-danger">*</span></h5>
    <input type="text" name="nama" class="form-control mb-3" required />


    <h5 class="card-title my-3">Username  <span class="text-danger">*</span></h5>
    <input type="text" name="username" class="form-control mb-3" required />


    <h5 class="card-title my-3">Password  <span class="text-danger">*</span></h5>
    <input type="password" name="password" class="form-control mb-3" required />

    <h5 class="card-title my-3">Konfirmasi Password  <span class="text-danger">*</span></h5>
    <input type="password" name="konfirmasi_password" class="form-control mb-3" required />

    <button type="submit" class="form-control btn btn-primary">Simpan</button>
</form>

<?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/user/create.blade.php ENDPATH**/ ?>