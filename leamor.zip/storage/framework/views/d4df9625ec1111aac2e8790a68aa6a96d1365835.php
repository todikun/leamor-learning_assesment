<?php $__env->startSection('title', 'Rapor'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3">Rapor Saya</h1>
    
</div>


<div class="container">
    <div class="row row-cols-md-3 row-cols-lg-6">
      <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col mb-2 text-center">
            <div class="d-inline-block position-relative">
                <a href="#" style="cursor: default">
                    <img src="<?php echo e(asset('dist/img/folder.png')); ?>" alt="err" width="50px" height="50px" />
                </a>
                <a href="<?php echo e(route('rapor.teacher.detail', $item->id)); ?>" title="Rapor" class=" bg-success text-white rounded-circle position-absolute" style="bottom: 0; right: 0;">
                    <i class="align-middle p-1" data-feather="file"></i> 
                </a>
            </div>            
            <h5 class="fw-bold"><?php echo e($item->nama); ?></h5>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          Data Not Found!
      <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<script>

    // event button add
    $('.btn-add').on('click', function (e) {
        e.preventDefault();
        var url = $(this).attr('href');

        $.ajax({
            url: url,
            dataType: 'HTML',
            method: 'GET',
            success: function (result) {
                $('#modal-form').find('.modal-title').html('Create Proyek');
                $('#modal-form').find('.modal-body').html(result);
                $('#modal-form').modal('show');
            },
            error: function (err) {
                console.log(err);
            },
        });
    });
    
    // event button edit
    $('.btn-edit').on('click', function (e) {
        e.preventDefault();
        var url = $(this).attr('href');

        $.ajax({
            url: url,
            dataType: 'HTML',
            method: 'GET',
            success: function (result) {
                $('#modal-form').find('.modal-title').html('Edit Proyek');
                $('#modal-form').find('.modal-body').html(result);
                $('#modal-form').modal('show');
            },
            error: function (err) {
                console.log(err);
            },
        });
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/teacher/rapor/index.blade.php ENDPATH**/ ?>