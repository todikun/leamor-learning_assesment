<?php $__env->startSection('title', 'Ujian'); ?>

<?php $__env->startSection('content'); ?>

<form id="formSoal" action="<?php echo e(route('ujian.nilai', $soal->id)); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="ujian_siswa_id" value="<?php echo e($siswa->id); ?>"/>
    <div class="row mb-3 justify-content-center pb-3">
        <div class="col-md-4 alert alert-success ms-auto">
            <h2 class="text-center my-3 fw-bold" id="waktuMundur"><?php echo e($soal->waktu_ujian); ?> menit 0 detik</h2>
            <h5>Topik <strong><?php echo e($soal->nama); ?></h5>
        </div>
    </div>
    <div class="row d-flex">
        <div class="col-md-2">
            <div class="nav flex-row nav-pills" id="v-pills-tab" role="tablist" aria-orientation="horizontal">
                <?php $__currentLoopData = $soal->SoalDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button style="width: 1.5rem; background-color: rgb(223, 232, 240)" class="nav-link cek-nav m-1 d-flex justify-content-center align-items-center <?php echo e($loop->iteration == 1 ? 'active':''); ?>" id="v-pills-soal_<?php echo e($loop->iteration); ?>-tab" data-index="<?php echo e($loop->iteration); ?>" data-bs-toggle="pill" data-bs-target="#v-pills-soal_<?php echo e($loop->iteration); ?>" type="button" role="tab" aria-controls="v-pills-soal_<?php echo e($loop->iteration); ?>" aria-selected="true">
                        <span class="text-center"><?php echo e($loop->iteration); ?></span>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        <div class="col-md-10">
            
            <div class="tab-content" id="v-pills-tabContent">
                <?php $__currentLoopData = $soal->SoalDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade show <?php echo e($loop->iteration == 1 ? 'active':''); ?>" id="v-pills-soal_<?php echo e($loop->iteration); ?>" role="tabpanel" aria-labelledby="v-pills-soal_<?php echo e($loop->iteration); ?>-tab">
                    <div class="card">
                        <div class="card-body">
                            <div class="row d-flex align-items-stretch">

                                <div class="col-md-5">
        
                                    
                                    <div class="col-md-12">
                                        <div class="row d-flex mb-3">
                                            <div class="col-md">
                                                <span class="mb-3 me-1">Stimulus</span>
                                            </div>
                                        </div>
                                        
                                        <?php $__currentLoopData = $item->stimulus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stimulus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="appendAreaStimulus_<?php echo e($key+1); ?>">
                                                
                                                <div class="row d-flex stimulus-container mb-2">
                                                    
                                                    <div class="col-md stimulus-tipe">
                                                        <?php
                                                            $audio = ['mp3'];
                                                            $video = ['mp4'];
                                                            $image  = ['png', 'jpg', 'jpeg'];
                                                            $extension = explode('.', $stimulus['value']);
                                                        ?>
                                                        <?php if($stimulus['tipe'] == 'teks'): ?>
                                                            <textarea class="form-control mb-2" cols="3" rows="3" required><?php echo e($stimulus['value']); ?></textarea>
                                                        <?php else: ?>
                                                        <li>
                                                            <?php if(in_array($extension[1], $audio)): ?>
                                                                <div class="d-flex justify-content-center align-items-center">
                                                                    <audio controls class="audio-player">
                                                                        <source src="<?php echo e(asset('uploads/'.$stimulus['value'])); ?>" type="audio/mpeg">
                                                                        Your browser does not support the audio element.
                                                                    </audio>
                                                                </div>
                                                            <?php endif; ?>
                                                            <?php if(in_array($extension[1], $video)): ?>
                                                                <div class="d-flex justify-content-center align-items-center">
                                                                    <button type="button" class="btn btn-secondary btn-xs my-1 btn-show" data-value="<?php echo e($stimulus['value']); ?>" data-jenis="Video">Show</button>
                                                                </div>
                                                            <?php endif; ?>
                                                            <?php if(in_array($extension[1], $image)): ?>
                                                                <div class="d-flex justify-content-center align-items-center">
                                                                    <button type="button" class="btn btn-secondary btn-xs my-1 btn-show" data-value="<?php echo e($stimulus['value']); ?>" data-jenis="Image">Show</button>
                                                                </div>
                                                            <?php endif; ?>
                                                        </li>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
        
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    
                                    <input type="hidden" name="feedback[]" value="<?php echo e($item->feedback ?? null); ?>" />
                            
                                    </div>
                                </div>

                                <div class="col-md-1 d-flex justify-content-center align-items-center">
                                    <div class="vr" style="border-left: 2px solid black;"></div>
                                </div>

                                
                                <div class="col-md-6">
                                    <div class="form-group mb-2">
                                        <h5 class="card-title mb-2">Pertanyaan </h5>
                                        <div>
                                            <?php echo $item->pertanyaan; ?>

                                        </div>
                                    </div>
    
                                    <hr>
        
                                    <div class="appendAreaOpsi_<?php echo e($key+1); ?>">
                                        <div class="row d-flex mb-3">
                                            <div class="col-md">
                                                <span class="mb-3 me-1">Opsi </span>
                                            </div>
                                        </div>
                                        <div class="col-md opsi-jawaban">
                                            <?php
                                                $pilihan_ganda = ['a','b','c','d'];
                                                $tipe_soal = $item->tipe_soal_id
                                            ?>
                                            <?php $__currentLoopData = $item->tipe_soal_id != '2' ? $item->opsi_jawaban : $item->opsi_jawaban[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j => $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php switch($item->tipe_soal_id):
                                                    case ('1'): ?>
                                                    
                                                        <div class="mb-3 d-flex">
                                                            <div class="col-md-1">
                                                                <input type="radio" value="<?php echo e($pilihan_ganda[$j]); ?>" name="no_<?php echo e($key+1); ?>" required />
                                                            </div>
                                                            <div class="col-md-11">
                                                                <div>
                                                                    <?php echo $jawaban; ?>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php break; ?>
                                                    <?php case ('2'): ?>
                                                    
                                                    <div class="mb-3 d-flex align-items-center justify-content-center">
                                                        <div class="col-md-6">
                                                            <div class="mb-3 d-flex">
                                                                <div class="col-md-1 ms-3">
                                                                    <input type="radio" value="<?php echo e($pilihan_ganda[$j]); ?>" name="no_<?php echo e($key+1); ?>_kiri" class="kunci-jawaban-value" required />
                                                                </div>
                                                                <div class="col-md-11">
                                                                    <?php echo $item->opsi_jawaban[0][$j]; ?>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="mb-3 d-flex">
                                                                <div class="col-md-1 ms-3">
                                                                    <input type="radio" value="<?php echo e($pilihan_ganda[$j]); ?>" name="no_<?php echo e($key+1); ?>_kanan" class="kunci-jawaban-value" required />
                                                                </div>
                                                                <div class="col-md-11">
                                                                    <?php echo $item->opsi_jawaban[1][$j]; ?>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                        <?php break; ?>
                                                    <?php case ('3'): ?>
                                                    
                                                    <?php
                                                        // dd($item->opsi_jawaban);
                                                    ?>
                                                        <input type="radio" name="no_<?php echo e($key+1); ?>" class="ms-3" value="<?php echo e($jawaban); ?>" /> <?php echo e($jawaban); ?>

                                                        <?php break; ?>
                                                    <?php case ('4'): ?>
                                                    
                                                        <textarea class="form-control mb-2" name="no_<?php echo e($key+1); ?>[]" cols="3" rows="3" required></textarea>
                                                        <?php break; ?>
                                                    <?php case ('5'): ?>
                                                    
                                                        <textarea class="form-control mb-2" name="no_<?php echo e($key+1); ?>" cols="3" rows="3" required></textarea>
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        
                                                <?php endswitch; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
    
                                    </div>
                                </div>
                            </div>
                        </div>
        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>

        </div>
        
    </div>
    <button type="submit" onclick="return confirm('Apa kamu yakin untuk mengakhiri ujian ini?')" class="form-control btn btn-success btn-lg position-sticky my-3 mx-1" style="float: right;">
        SUBMIT
    </button>
    

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <style>      
        @keyframes  zoomIn {
            0% {
                transform: scale(0.5);
            }
            100% {
                transform: scale(1);
            }
        }
        @keyframes  zoomOut {
            0% {
                transform: scale(1);
            }
            100% {
                transform: scale(0.5);
            }
        }

        .zoom-in-out {
            width: auto;
            height: auto;
            animation: zoomIn 1.5s alternate infinite; 
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script> 
        var myModal = $('#modal-form');
        var modalReminder = $('#modal-reminder');

        $(document).ready(function(){
            $('.cek-nav.active').css('background-color', 'blue');
            $('.cek-nav.active span').css('color', 'white');
            $('.cek-nav:not(.active) span').css('color', 'black');
            
            $('.cek-nav').click(function(){
                $('.cek-nav').css('background-color', 'rgb(223, 232, 240)');
                $('.cek-nav span').css('color', 'black');

                if($(this).hasClass('active')) {
                    $(this).css('background-color', 'blue');
                    $(this).find('span').css('color', 'white');
                } 
            });

            modalReminder.find('.modal-title').html('Reminder');
            modalReminder.find('.modal-body').html('<p>Perhatikan Soal dengan seksama, dan jawab dengan teliti!</p>');
            modalReminder.modal('show');
            
            var detik = 0;
            var menit = "<?php echo e($soal->waktu_ujian); ?>" ?? 20;
            // var menit = 1;
            function hitung() {
                setTimeout(hitung, 1000);
                $('#waktuMundur').html(menit + ' menit ' + detik + ' detik ');
     
                if (menit === 5 && detik === 0) {
                    $('#waktuMundur').addClass('text-danger');
                    $('#waktuMundur').addClass('zoom-in-out');
                }
     
                detik--;
                if (detik < 0) {
                    detik = 59;
                    menit--;
                    if (menit < 0) {
                        menit = 0;
                        detik = 0;
                        setInterval(function () {
                            $('#waktuMundur').html('Waktu habis!');
                            $('#formSoal').submit();
                        }, 1000);
                    }
                }
            }

            modalReminder.on('hidden.bs.modal', function(){
                hitung();
            });

            stopAudioPlayer();

        });

        $('.btn-show').on('click',function(){
            var jenisDokumen = $(this).attr('data-jenis');
            var baseUrl = "<?php echo e(env('APP_URL')); ?>";
            var dokumen = baseUrl + '/uploads/' + $(this).attr('data-value');
            var html = ''
            if (jenisDokumen == 'Video') {
                html = `
                <video controls width="100%" height="auto">
                    <source src="${dokumen}" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
                `;
            }
            if (jenisDokumen == 'Image') {
                html = `
                <img src=${dokumen} class="rounded" width="100 height="auto />
                `;
            }
            myModal.find('.modal-title').html(jenisDokumen);
            myModal.find('.modal-body').html(html);
            myModal.modal('show');
        });

        function stopAudioPlayer() {
            var audioPlayers = document.querySelectorAll('.audio-player');
            audioPlayers.forEach(function(player) {
                player.addEventListener('play', function() {
                    audioPlayers.forEach(function(otherPlayer) {
                        if (otherPlayer !== player) {
                            otherPlayer.pause();
                        }
                    });
                });
            });
        }   
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/ujian/soal.blade.php ENDPATH**/ ?>