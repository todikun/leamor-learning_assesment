<footer class="footer">
	<div class="container-fluid">
		<div class="row text-muted">
			<div class="col-6 text-start">
				<p class="mb-0">
					<span class="text-muted">
						&copy; 2024 <strong>Olyivia Retdwina Rusma</strong>
					</span>
				</p>
			</div>
		</div>
	</div>
</footer><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/components/footer.blade.php ENDPATH**/ ?>