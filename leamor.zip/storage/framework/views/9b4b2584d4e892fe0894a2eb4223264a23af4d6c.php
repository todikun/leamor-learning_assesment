<?php $__env->startSection('title', 'Soal'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3">Rapor Ujian: <strong><?php echo e($data->Soal->nama ?? '-'); ?></strong> </h1>
    <h2 class="h3"><strong><?php echo e($data->Siswa->nama); ?></strong>, Peringkat: <strong><?php echo e($rank); ?></strong>, Total Skor: <strong><?php echo e($data->total_nilai); ?></strong></h2>
    <a href="<?php echo e(route('export.permateri', $data->id)); ?>" class="btn btn-danger">
        <i class="fa fa-file"></i> PDF
    </a>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <table id="myTable" class="table">
                    <thead>
                        <tr class="text-center" style="background-color: #79dfc1;">
                            <th>No</th>
                            <th>Tipe Soal</th>
                            <th>Soal</th>
                            <th>Feedback</th>
                            <th>Jawaban</th>
                            <th>Koreksi</th>
                            <th>Skor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data->Soal->SoalDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->TipeSoal->nama); ?></td>
                                <td><?php echo $item->pertanyaan; ?></td>
                                <td>
                                    <?php if($data->feedback[$key] == null && auth()->user()->role == 'teacher'): ?>
                                        <a href="<?php echo e(route('rapor.teacher.feedback', [$data->id,'index'=>$key])); ?>" class="text-danger btn-feedback">Isi feedback</a>
                                    <?php else: ?>    
                                        <?php echo $data->feedback[$key] ?? '-'; ?></td>
                                    <?php endif; ?>

                                <td>
                                    <?php if(is_array($data->jawaban[$key])): ?>
                                        <?php $__currentLoopData = $data->jawaban[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $j; ?>, 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php echo $data->jawaban[$key]; ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="text-<?php echo e($data->nilai[$key] != '0' ? 'success':'danger'); ?> ms-1">
                                        <i class="fa fa-<?php echo e($data->nilai[$key] != '0' ? 'check':'times'); ?>"></i>
                                    </span>
                                </td>
                                <td><?php echo e($data->nilai[$key]); ?> 
                                <?php
                                    // isian singkat = 4
                                    // essay = 5
                                    $soal_koreksi = ['5', '4'];
                                ?>
                                <?php if(in_array($item->tipe_soal_id, $soal_koreksi) && auth()->user()->role == 'teacher' && $data->nilai[$key] == '0'): ?>
                                    
                                    <a href="<?php echo e(route('rapor.teacher.koreksi', [$data->id, 'index'=>$key])); ?>" class="fa fa-edit text-warning ms-1 btn-koreksi"></a>
                                <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%" class="text-center">No data</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php if($data->is_selesai == '0' && $data->Soal->created_by == auth()->user()->id && auth()->user()->role == 'teacher'): ?>
                    <a href="<?php echo e(route('rapor.teacher.submit', $data->id)); ?>" onclick="return confirm('Apa anda yakin akan submit rapor ini?')" class="form-control btn btn-success">Submit</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<script>
    
    $('.btn-feedback').on('click', function (e) {
        e.preventDefault();
        var url = $(this).attr('href');
        var modalSize = $(this).attr('data-modal') ?? '';

        $.ajax({
            url: url,
            dataType: 'HTML',
            method: 'GET',
            success: function (result) {
                modalForm(result, 'Update Feedback');
            },
            error: function (err) {
                console.log(err);
            },
        });
    });

    $('.btn-koreksi').on('click', function (e) {
        e.preventDefault();
        var url = $(this).attr('href');
        var modalSize = $(this).attr('data-modal') ?? '';

        $.ajax({
            url: url,
            dataType: 'HTML',
            method: 'GET',
            success: function (result) {
                modalForm(result, 'Koreksi Soal', 'modal-xs');
            },
            error: function (err) {
                console.log(err);
            },
        });
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/todirhmt/HDD1/Laravel-Project/git/leamor-riset-olyivia/resources/views/pages/student/rapor/rank.blade.php ENDPATH**/ ?>